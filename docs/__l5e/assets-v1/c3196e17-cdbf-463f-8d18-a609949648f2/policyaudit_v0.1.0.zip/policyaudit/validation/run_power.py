"""Supplementary: decision rates at larger pilots (50 reps).  python validation/run_power.py"""
import sys
from pathlib import Path
import pandas as pd
from joblib import Parallel, delayed
sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_validation as v
import policyaudit as pa

SC = ["no_shift", "covariate_shift", "small_shift", "moderate_shift", "intercept_drop", "nonlinear"]
NS = [400, 1600, 3200, 6400]
rows = Parallel(n_jobs=2, batch_size=2)(delayed(v.one)(s, n, i) for s in SC for n in NS for i in range(50))
d = pd.DataFrame(rows)
d.to_csv(Path(__file__).with_name("power_runs.csv"), index=False)
t = d.groupby(["scenario", "n"], sort=False).decision.value_counts(normalize=True).unstack().fillna(0)
t.to_csv(Path(__file__).with_name("power_summary.csv"))
print(t.round(2).to_string())
