"""Simulation validation of policyaudit's default settings on known-truth scenarios.

For each scenario and pilot size, repeatedly: draw a pilot, run audit() with defaults,
and score the decision against the truth on 20,000 fresh target units.

Truth labels
  source_ok      : true regret of the source policy (vs the oracle that knows tau) <= tolerance
Metrics
  keep / recal / more rates
  false_keep     : KEEP although source_ok is False          (false reassurance)
  false_recal    : RECALIBRATE although the deployed recalibrated policy is worse than the source
  deployed_regret: true regret of what is deployed (source for KEEP, recalibrated model for RECAL;
                   MORE excluded)
  lower_ok/upper_ok : one-sided bounds contain the true gain of the reported challenger
                   (fitted on the full pilot), evaluated on the fresh target units

python validation/run_validation.py [reps]     (~30 min with 2 cores at reps=100)
"""
from __future__ import annotations

import sys
from pathlib import Path
import numpy as np
import pandas as pd
from joblib import Parallel, delayed

import policyaudit as pa
from policyaudit.demo import SCENARIOS, _draw, source_model

OUT = Path(__file__).resolve().parent
COST, EPS = 0.5, 0.01
SCEN = dict(SCENARIOS)
SCEN["noisy_moderate_shift"] = dict(delta=1.0, d1=-1.0, sigma=3.0)
NS = [400, 1600]


def one(name, n, rep):
    sc = SCEN[name]
    seed = 1000 + rep
    f = source_model(seed=seed, eta=sc.get("eta", 0.0))
    rng = np.random.default_rng([seed, 7, n])
    X, T, Y, _ = _draw(rng, n, 0.5, True, **sc)
    pilot = pd.DataFrame({"x1": X[:, 0], "x2": X[:, 1], "T": T, "Y": Y, "s": f(X)})
    Xt, _, _, tau = _draw(np.random.default_rng([seed, 8]), 20000, 0.5, True, **sc)
    test = pd.DataFrame({"x1": Xt[:, 0], "x2": Xt[:, 1], "s": f(Xt)})
    r = pa.audit(pilot, ["x1", "x2"], "T", "Y", "s", 0.5, cost=COST, tolerance=EPS, seed=rep, flexible_check=(name == "nonlinear"))
    regret = lambda pol: float(np.mean(((tau > COST).astype(float) - pol) * (tau - COST)))
    pol_s = (test.s.to_numpy() > COST).astype(float)
    pol_r = (r.predict(test, "s") > COST).astype(float)
    true_gain = float(np.mean((pol_r - pol_s) * (tau - COST)))
    src_reg, rec_reg = regret(pol_s), regret(pol_r)
    dep = src_reg if r.decision == pa.KEEP else (rec_reg if r.decision == pa.RECAL else np.nan)
    return dict(scenario=name, n=n, rep=rep, decision=r.decision, challenger=r.recalibration,
                source_regret=src_reg, recal_regret=rec_reg, deployed_regret=dep, true_gain=true_gain,
                lower=r.gain_lower, upper=r.gain_upper, n_disagree=r.n_disagree,
                flex_warning=any("flexible" in w for w in r.warnings))


def main(reps=100):
    tasks = [(s, n, i) for s in SCEN for n in NS for i in range(reps)]
    rows = Parallel(n_jobs=2, batch_size=4, verbose=2)(delayed(one)(*t) for t in tasks)
    d = pd.DataFrame(rows)
    d.to_csv(OUT / "validation_runs.csv", index=False)
    d["source_ok"] = d.source_regret <= EPS
    g = d.groupby(["scenario", "n"], sort=False)
    summ = pd.DataFrame({
        "source_regret": g.source_regret.mean(),
        "source_ok_rate": g.source_ok.mean(),
        "keep": g.decision.apply(lambda x: np.mean(x == pa.KEEP)),
        "recalibrate": g.decision.apply(lambda x: np.mean(x == pa.RECAL)),
        "collect_more": g.decision.apply(lambda x: np.mean(x == pa.MORE)),
        "false_keep": g.apply(lambda x: np.mean((x.decision == pa.KEEP) & ~x.source_ok)),
        "false_recal": g.apply(lambda x: np.mean((x.decision == pa.RECAL) & (x.recal_regret > x.source_regret))),
        "deployed_regret": g.deployed_regret.mean(),
        "lower_ok": g.apply(lambda x: np.mean(x.lower <= x.true_gain)),
        "upper_ok": g.apply(lambda x: np.mean(x.upper >= x.true_gain)),
        "flex_warning": g.flex_warning.mean(),
    }).reset_index()
    summ.to_csv(OUT / "validation_summary.csv", index=False)
    print(summ.round(4).to_string())


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 100)
