import json
import pickle
import subprocess
import sys

import numpy as np
import pandas as pd
import pytest

import policyaudit as pa
from policyaudit.audit import _mean_bounds, _blp_slope
from policyaudit.learners import ShrinkToSource, LinearRefit

F = ["age_z", "risk_z"]
KW = dict(features=F, treatment="treated", outcome="outcome", source_cate="source_effect",
          propensity=0.5, cost=0.5, tolerance=0.01, flexible_check=False)


def run(df, **kw):
    a = dict(KW); a.update(kw)
    return pa.audit(df, **a)


def test_large_shift_recalibrates_and_improves_decisions():
    df = pa.make_demo("large_shift", n=800, seed=3, with_truth=True)
    r = run(df)
    assert r.decision == pa.RECAL and r.gain_lower > 0.5
    new = pa.make_demo("large_shift", n=4000, seed=4, with_truth=True)
    tau = new.true_effect.to_numpy()
    regret = lambda pol: np.mean(((tau > 0.5).astype(float) - pol) * (tau - 0.5))
    assert regret(r.recommend(new, "source_effect")) < 0.05 < regret((new.source_effect > 0.5).astype(float))


def test_no_shift_large_pilot_keeps():
    r = run(pa.make_demo("no_shift", n=3000, seed=5))
    assert r.decision == pa.KEEP


def test_keep_recommend_equals_source_policy():
    df = pa.make_demo("no_shift", n=3000, seed=5)
    r = run(df)
    assert np.array_equal(r.recommend(df, "source_effect"), (df.source_effect > 0.5).astype(int).to_numpy())


def test_input_validation():
    df = pa.make_demo("no_shift", n=200, seed=1)
    with pytest.raises(ValueError, match="columns not found"):
        run(df, features=["nope"])
    bad = df.assign(treated=df.treated * 2)
    with pytest.raises(ValueError, match="0/1"):
        run(bad)
    with pytest.raises(ValueError, match="between 0 and 1"):
        run(df, propensity=1.0)
    with pytest.raises(ValueError, match="at least 50"):
        run(df.head(40))


def test_missing_rows_dropped_with_warning_and_categoricals_ok():
    df = pa.make_demo("small_shift", n=600, seed=2)
    df.loc[:4, "outcome"] = np.nan
    df["site"] = np.where(df.age_z > 0, "A", "B")
    r = run(df, features=F + ["site"])
    assert r.n == 595 and any("Dropped 5 rows" in w for w in r.warnings)


def test_propensity_column_and_lower_is_better_symmetry():
    df = pa.make_demo("moderate_shift", n=1000, seed=7)
    r1 = run(df)
    flipped = df.assign(outcome=-df.outcome, p=0.5)
    r2 = run(flipped, propensity="p", higher_is_better=False)
    assert r1.decision == r2.decision and np.isclose(r1.gain_estimate, r2.gain_estimate)


def test_deterministic_given_seed():
    df = pa.make_demo("small_shift", n=500, seed=8)
    assert run(df, seed=1).to_dict() == run(df, seed=1).to_dict()


def test_mean_bounds_cover_and_order():
    rng = np.random.default_rng(0)
    hits = 0
    for _ in range(300):
        x = rng.normal(1.0, 2.0, 200)
        m, se, lo, hi = _mean_bounds(x, 0.05, rng, 300)
        assert lo <= m <= hi
        hits += lo <= 1.0
    assert hits / 300 > 0.9


def test_blp_slope_recovers_one_when_calibrated():
    rng = np.random.default_rng(1)
    pred = rng.normal(size=5000)
    slope, ci = _blp_slope(pred + rng.normal(size=5000), pred)
    assert abs(slope - 1) < 0.06 and ci[0] < slope < ci[1]
    slope0, _ = _blp_slope(rng.normal(size=5000), pred)   # no real heterogeneity
    assert abs(slope0) < 0.1


def test_shrink_interpolates_between_source_and_refit():
    rng = np.random.default_rng(2)
    X = rng.normal(size=(400, 2)); T = rng.binomial(1, 0.5, 400)
    tau = 1 + X[:, 0]
    Y = X[:, 1] + T * tau + rng.normal(size=400)
    s_good, s_bad = tau.copy(), np.full(400, -3.0)
    a = ShrinkToSource().fit(X, T, Y, s_good, rng)
    b = ShrinkToSource().fit(X, T, Y, s_bad, rng)
    assert a.lam > b.lam
    lin = LinearRefit().fit(X, T, Y)
    assert np.abs(b.predict_cate(X, s_bad) - lin.predict_cate(X)).mean() < 0.3


def test_json_pickle_and_report(tmp_path):
    r = run(pa.make_demo("intercept_drop", n=600, seed=1))
    d = json.loads(r.to_json())
    assert d["decision"] in (pa.KEEP, pa.RECAL, pa.MORE)
    r2 = pickle.loads(pickle.dumps(r))
    df = pa.make_demo("no_shift", n=100, seed=3)
    assert np.allclose(r.predict(df, "source_effect"), r2.predict(df, "source_effect"))
    from policyaudit.report import to_html
    assert r.decision in to_html(r)


def test_cli_roundtrip(tmp_path):
    p = tmp_path / "p.csv"
    subprocess.run([sys.executable, "-m", "policyaudit.cli", "demo", "--scenario", "large_shift", "--n", "500",
                    "--out", str(p)], check=True, capture_output=True)
    out = subprocess.run([sys.executable, "-m", "policyaudit.cli", "run", str(p), "--features", *F,
                          "--treatment", "treated", "--outcome", "outcome", "--source-cate", "source_effect",
                          "--cost", "0.5", "--tolerance", "0.01", "--no-flexible-check",
                          "--report", str(tmp_path / "r.html"), "--save-model", str(tmp_path / "m.pkl")],
                         capture_output=True, text=True)
    assert out.returncode == 0 and "RECALIBRATE" in out.stdout
    subprocess.run([sys.executable, "-m", "policyaudit.cli", "apply", str(tmp_path / "m.pkl"), str(p),
                    "--source-cate", "source_effect", "--out", str(tmp_path / "rec.csv")], check=True)
    assert "recommend_treat" in pd.read_csv(tmp_path / "rec.csv").columns
