"""Minimal end-to-end example: python examples/quickstart.py"""
import policyaudit as pa
from policyaudit.report import to_html

pilot = pa.make_demo("intercept_drop", n=1600, seed=0)        # replace with pd.read_csv("your_pilot.csv")
result = pa.audit(pilot, features=["age_z", "risk_z"], treatment="treated", outcome="outcome",
                  source_cate="source_effect", propensity=0.5, cost=0.5, tolerance=0.01)
print(result.summary())
open("quickstart_report.html", "w", encoding="utf-8").write(to_html(result, dataset_name="demo: intercept_drop"))

new_people = pa.make_demo("intercept_drop", n=10, seed=1)
print(new_people.assign(treat=result.recommend(new_people, "source_effect"))[["age_z", "risk_z", "source_effect", "treat"]])
