"""Generate the LaTeX fragments used by the manual from real outputs (no hand-typed numbers).

python docs/make_tables.py   (run from the package root after the validation scripts)
"""
from pathlib import Path
import pandas as pd
import policyaudit as pa

ROOT = Path(__file__).resolve().parents[1]
GEN = ROOT / "docs" / "generated"
GEN.mkdir(exist_ok=True)
NAMES = {"no_shift": "No shift", "covariate_shift": "Covariate shift only", "irrelevant_shift": "Large but decision-irrelevant shift",
         "small_shift": "Small effect shift", "moderate_shift": "Moderate effect shift", "large_shift": "Large effect shift",
         "intercept_drop": "Effect drops for everyone", "nonlinear": "Nonlinear effect (misspecified)",
         "noisy_moderate_shift": "Moderate shift, noisy outcome"}
pct = lambda x: f"{100 * x:.0f}\\%"

# ---------------------------------------------------------------- validation table
v = pd.read_csv(ROOT / "validation" / "validation_summary.csv")
rows = []
for _, r in v.iterrows():
    rows.append(f"{NAMES[r.scenario]} & {r.n:,} & {r.source_regret:.4f} & {pct(r.keep)} & {pct(r.recalibrate)} & "
                f"{pct(r.collect_more)} & {pct(r.false_keep)} & {pct(r.false_recal)} & "
                f"{'--' if pd.isna(r.deployed_regret) else f'{r.deployed_regret:.4f}'} \\\\")
(GEN / "validation_rows.tex").write_text("\n".join(rows).replace(",", "{,}"))
s = dict(max_false_keep=v.false_keep.max(), max_false_recal=v.false_recal.max(),
         min_lower_ok=v.lower_ok.min(), min_upper_ok=v.upper_ok.min(),
         min_upper_ok_ex=v[v.scenario != "irrelevant_shift"].upper_ok.min(),
         reps=int(pd.read_csv(ROOT / "validation" / "validation_runs.csv").rep.max() + 1))
(GEN / "validation_macros.tex").write_text("\n".join([
    f"\\newcommand{{\\maxFalseKeep}}{{{pct(s['max_false_keep'])}}}",
    f"\\newcommand{{\\maxFalseRecal}}{{{pct(s['max_false_recal'])}}}",
    f"\\newcommand{{\\minLowerOK}}{{{s['min_lower_ok']:.2f}}}",
    f"\\newcommand{{\\minUpperOK}}{{{s['min_upper_ok']:.2f}}}",
    f"\\newcommand{{\\minUpperOKex}}{{{s['min_upper_ok_ex']:.2f}}}",
    f"\\newcommand{{\\valReps}}{{{s['reps']}}}",
    f"\\newcommand{{\\nonlinFlex}}{{{pct(v[(v.scenario=='nonlinear')&(v.n==1600)].flex_warning.iloc[0])}}}",
]))

# ------------------------------------------------- severity of the errors made
runs = pd.concat([pd.read_csv(ROOT / "validation" / "validation_runs.csv"),
                  pd.read_csv(ROOT / "validation" / "power_runs.csv")], ignore_index=True)
pw = pd.read_csv(ROOT / "validation" / "power_runs.csv")
pw_fk = pw.assign(f=(pw.decision == "KEEP") & (pw.source_regret > 0.01)).groupby(["scenario", "n"]).f.mean().max()
fk = runs[(runs.decision == "KEEP") & (runs.source_regret > 0.01)]
fr = runs[(runs.decision == "RECALIBRATE") & (runs.recal_regret > runs.source_regret)]
with open(GEN / "validation_macros.tex", "a") as f:
    f.write(f"\n\\newcommand{{\\worstFalseKeep}}{{{fk.source_regret.max():.3f}}}"
            f"\n\\newcommand{{\\worstFalseRecal}}{{{(fr.recal_regret - fr.source_regret).max():.4f}}}"
            f"\n\\newcommand{{\\maxFalseKeepPower}}{{{100*pw_fk:.0f}\\%}}"
            f"\n\\newcommand{{\\nRuns}}{{{len(runs):,}}}\n".replace(",", "{,}"))

# ---------------------------------------------------------------- power table
p = ROOT / "validation" / "power_summary.csv"
if p.exists():
    t = pd.read_csv(p)
    out = []
    for _, r in t.iterrows():
        out.append(f"{NAMES[r.scenario]} & {int(r.n):,} & {pct(r.get('KEEP', 0))} & {pct(r.get('RECALIBRATE', 0))} & "
                   f"{pct(r.get('COLLECT MORE', 0))} \\\\")
    (GEN / "power_rows.tex").write_text("\n".join(out).replace(",", "{,}"))

# ---------------------------------------------------------------- worked example
df = pa.make_demo("intercept_drop", n=1600, seed=0)
df.head(5).round(3).to_csv(GEN / "example_head.csv", index=False)
r = pa.audit(df, ["age_z", "risk_z"], "treated", "outcome", "source_effect", 0.5, cost=0.5, tolerance=0.01)
(GEN / "example_summary.txt").write_text(r.summary())
head = df.head(5).round(3)
lines = [" & ".join(head.columns.str.replace("_", r"\_")) + r" \\ \midrule"]
lines += [" & ".join(f"{x:g}" for x in row) + r" \\" for row in head.itertuples(index=False)]
(GEN / "example_head.tex").write_text("\n".join(lines))
print("generated:", sorted(x.name for x in GEN.iterdir()))
