"""Synthetic example data (the Experiment 002 data-generating process).

A linear effect model is trained on a randomized source sample; a randomized target
pilot is then drawn from a chosen scenario and scored with the source model.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

SCENARIOS = {
    "no_shift": dict(delta=0.0),
    "covariate_shift": dict(delta=1.0),
    "irrelevant_shift": dict(delta=2.0, d0=1.0),
    "small_shift": dict(delta=0.0, d1=-0.5),
    "moderate_shift": dict(delta=1.0, d1=-1.0),
    "large_shift": dict(delta=1.0, d1=-3.0),
    "intercept_drop": dict(delta=0.0, d0=-0.75),
    "nonlinear": dict(delta=1.0, eta=0.6),
}


def _tau(X, delta=0.0, d0=0.0, d1=0.0, eta=0.0, target=True):
    x1, x2 = X[:, 0], X[:, 1]
    t = 1 + 1.5 * x1 - 0.8 * x2 + eta * (x1 ** 2 - 1)
    return t + (d0 + d1 * x1 if target else 0.0)


def _draw(rng, n, p, target, sigma=1.0, **sc):
    mean = sc.get("delta", 0.0) * np.array([1.0, -0.5]) if target else np.zeros(2)
    X = rng.normal(size=(n, 2)) + mean
    tau = _tau(X, target=target, **sc)
    T = rng.binomial(1, p, n)
    base = 2 + 0.7 * X[:, 0] + 0.4 * X[:, 1] + 0.3 * X[:, 0] * X[:, 1]
    Y = base + T * tau + sigma * rng.normal(size=n)
    return X, T, Y, tau


def source_model(n_source=3000, seed=0, p=0.5, **sc):
    """Fit the source linear effect model; returns a function X -> predicted effect."""
    rng = np.random.default_rng([seed, 1])
    X, T, Y, _ = _draw(rng, n_source, p, False, **sc)
    B = np.column_stack([np.ones(len(X)), X, X[:, 0] * X[:, 1]])
    E = np.column_stack([np.ones(len(X)), X])
    coef = np.linalg.lstsq(np.column_stack([B, T[:, None] * E]), Y, rcond=None)[0][-3:]
    return lambda Xn: coef[0] + Xn[:, 0] * coef[1] + Xn[:, 1] * coef[2]


def make_demo(scenario="moderate_shift", n=800, seed=0, p=0.5, with_truth=False, **override):
    """Return a pilot DataFrame with columns age_z, risk_z, treated, outcome, source_effect."""
    sc = dict(SCENARIOS[scenario]); sc.update(override)
    f = source_model(seed=seed, p=p, eta=sc.get("eta", 0.0))
    rng = np.random.default_rng([seed, 2])
    X, T, Y, tau = _draw(rng, n, p, True, **sc)
    df = pd.DataFrame({"age_z": X[:, 0], "risk_z": X[:, 1], "treated": T, "outcome": Y, "source_effect": f(X)})
    if with_truth:
        df["true_effect"] = tau
    return df
