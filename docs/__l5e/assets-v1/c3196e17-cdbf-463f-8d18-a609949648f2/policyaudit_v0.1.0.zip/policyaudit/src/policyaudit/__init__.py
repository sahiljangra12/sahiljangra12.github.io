"""policyaudit: keep, recalibrate, or collect more? A decision audit for treatment
policies moved to a new setting, using a small randomized pilot."""
from .audit import audit, AuditResult, KEEP, RECAL, MORE
from .demo import make_demo, SCENARIOS

__version__ = "0.1.0"
__all__ = ["audit", "AuditResult", "make_demo", "SCENARIOS", "KEEP", "RECAL", "MORE"]
