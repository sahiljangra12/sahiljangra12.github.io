"""Command-line interface.

  policyaudit run pilot.csv --features age bmi --treatment treated --outcome y \
      --source-cate predicted_effect --propensity 0.5 --cost 0.5 --tolerance 0.01 \
      --report report.html --json result.json --save-model model.pkl
  policyaudit apply model.pkl new_people.csv --source-cate predicted_effect --out decisions.csv
  policyaudit demo --scenario moderate_shift --n 800 --out pilot.csv
  policyaudit app
"""
from __future__ import annotations

import argparse
import pickle
import subprocess
import sys
from pathlib import Path

import pandas as pd

from . import __version__
from .audit import audit
from .demo import make_demo, SCENARIOS
from .report import to_html


def _num_or_col(v):
    try:
        return float(v)
    except ValueError:
        return v


def cmd_run(a):
    df = pd.read_csv(a.data)
    r = audit(df, a.features, a.treatment, a.outcome, a.source_cate, _num_or_col(a.propensity), cost=a.cost,
              tolerance=a.tolerance, alpha=a.alpha, looks=a.looks, recalibration=a.recalibration,
              challengers=a.challengers, folds=a.folds, n_boot=a.n_boot, min_disagreements=a.min_disagreements,
              min_recal_n=a.min_recal_n, flexible_check=not a.no_flexible_check,
              higher_is_better=not a.lower_is_better, seed=a.seed)
    print(r.summary())
    if a.report:
        Path(a.report).write_text(to_html(r, dataset_name=Path(a.data).name), encoding="utf-8")
        print(f"\nReport written to {a.report}")
    if a.json:
        r.to_json(a.json); print(f"JSON written to {a.json}")
    if a.save_model:
        with open(a.save_model, "wb") as f:
            pickle.dump(r, f)
        print(f"Audit (with recalibrated model) saved to {a.save_model}")
    return 0 if r.decision != "COLLECT MORE" else 3


def cmd_apply(a):
    with open(a.model, "rb") as f:
        r = pickle.load(f)
    df = pd.read_csv(a.data)
    df["recommend_treat"] = r.recommend(df, a.source_cate)
    df["recalibrated_effect"] = r.predict(df, a.source_cate)
    df.to_csv(a.out, index=False)
    print(f"Decision in saved audit: {r.decision}. Wrote {len(df)} recommendations to {a.out}")
    return 0


def cmd_demo(a):
    df = make_demo(a.scenario, n=a.n, seed=a.seed, with_truth=a.with_truth)
    df.to_csv(a.out, index=False)
    print(f"Wrote {len(df)} synthetic pilot rows ({a.scenario}) to {a.out}\n"
          f"Try: policyaudit run {a.out} --features age_z risk_z --treatment treated --outcome outcome "
          f"--source-cate source_effect --propensity 0.5 --cost 0.5 --tolerance 0.01 --report report.html")
    return 0


def cmd_app(a):
    app = Path(__file__).with_name("app.py")
    return subprocess.call([sys.executable, "-m", "streamlit", "run", str(app)])


def build_parser():
    p = argparse.ArgumentParser(prog="policyaudit", description="Keep, recalibrate, or collect more? Audit a treatment "
                                "policy in a new setting using a small randomized pilot.")
    p.add_argument("--version", action="version", version=f"policyaudit {__version__}")
    sub = p.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("run", help="audit a pilot CSV")
    r.add_argument("data", help="pilot CSV, one row per unit")
    r.add_argument("--features", nargs="+", required=True, help="covariate columns")
    r.add_argument("--treatment", required=True, help="0/1 treatment column")
    r.add_argument("--outcome", required=True, help="outcome column")
    r.add_argument("--source-cate", required=True, help="column with the source model's predicted effect")
    r.add_argument("--propensity", default="0.5", help="known treatment probability, or a column name (default 0.5)")
    r.add_argument("--cost", type=float, default=0.0, help="treat when predicted benefit exceeds this (default 0)")
    r.add_argument("--tolerance", type=float, required=True, help="acceptable per-person loss from not recalibrating")
    r.add_argument("--alpha", type=float, default=0.05)
    r.add_argument("--looks", type=int, default=1, help="planned number of looks at a growing pilot (Bonferroni)")
    r.add_argument("--recalibration", default="shrink", choices=["shrink", "linear", "forest"])
    r.add_argument("--challengers", nargs="+", default=["shrink", "linear"], choices=["shrink", "linear", "forest"])
    r.add_argument("--folds", type=int, default=5)
    r.add_argument("--n-boot", type=int, default=2000)
    r.add_argument("--min-disagreements", type=int, default=20)
    r.add_argument("--min-recal-n", type=int, default=400)
    r.add_argument("--no-flexible-check", action="store_true", help="skip the random-forest diagnostic (faster)")
    r.add_argument("--lower-is-better", action="store_true", help="outcome is bad when high (e.g. cost, readmissions)")
    r.add_argument("--seed", type=int, default=0)
    r.add_argument("--report", help="write an HTML report here")
    r.add_argument("--json", help="write results as JSON here")
    r.add_argument("--save-model", help="pickle the audit and recalibrated model here (for 'apply')")
    r.set_defaults(fn=cmd_run)

    ap = sub.add_parser("apply", help="recommend treatment for new units with a saved audit")
    ap.add_argument("model"); ap.add_argument("data")
    ap.add_argument("--source-cate", required=True); ap.add_argument("--out", default="recommendations.csv")
    ap.set_defaults(fn=cmd_apply)

    d = sub.add_parser("demo", help="write a synthetic pilot CSV to try the tool")
    d.add_argument("--scenario", default="moderate_shift", choices=list(SCENARIOS))
    d.add_argument("--n", type=int, default=800); d.add_argument("--seed", type=int, default=0)
    d.add_argument("--with-truth", action="store_true", help="include the true effect column")
    d.add_argument("--out", default="demo_pilot.csv")
    d.set_defaults(fn=cmd_demo)

    app = sub.add_parser("app", help="open the point-and-click app (needs: pip install policyaudit[app])")
    app.set_defaults(fn=cmd_app)
    return p


def main(argv=None):
    a = build_parser().parse_args(argv)
    try:
        return a.fn(a)
    except ValueError as err:
        print(f"error: {err}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
