"""Point-and-click app:  policyaudit app   (or: streamlit run app.py)"""
import io
import pickle

import pandas as pd
import streamlit as st

from policyaudit import audit, make_demo, SCENARIOS, KEEP, RECAL
from policyaudit.report import to_html

st.set_page_config(page_title="policyaudit", page_icon="⚖️", layout="centered")
st.title("Keep, recalibrate, or collect more?")
st.write("Check whether a treatment-targeting policy built elsewhere still works in a new setting, "
         "using a small **randomized** pilot. Upload one row per pilot unit with: the covariates, "
         "a 0/1 treatment column, the outcome, and your existing model's predicted effect for that unit.")

with st.sidebar:
    st.header("Data")
    src = st.radio("Source", ["Upload CSV", "Try a demo"], horizontal=True)
    if src == "Upload CSV":
        up = st.file_uploader("Pilot CSV", type="csv")
        df = pd.read_csv(up) if up else None
        name = up.name if up else None
    else:
        sc = st.selectbox("Demo scenario", list(SCENARIOS), index=list(SCENARIOS).index("moderate_shift"))
        n = st.select_slider("Pilot size", [200, 400, 800, 1600, 3200], value=800)
        df = make_demo(sc, n=n, seed=0)
        name = f"demo: {sc}"

if df is None:
    st.info("Upload a pilot CSV in the sidebar, or switch to *Try a demo*.")
    st.stop()

st.subheader("1 · Columns")
st.dataframe(df.head(8))
cols = list(df.columns)
guess = lambda opts, default: opts.index(default) if default in opts else 0
c1, c2, c3 = st.columns(3)
treatment = c1.selectbox("Treatment (0/1)", cols, index=guess(cols, "treated"))
outcome = c2.selectbox("Outcome", cols, index=guess(cols, "outcome"))
source = c3.selectbox("Source model's predicted effect", cols, index=guess(cols, "source_effect"))
features = st.multiselect("Covariates", [c for c in cols if c not in (treatment, outcome, source)],
                          default=[c for c in cols if c not in (treatment, outcome, source, "true_effect")][:10])

st.subheader("2 · Decision settings")
c1, c2, c3 = st.columns(3)
prop_mode = c1.radio("Treatment probability", ["Constant", "Column"], horizontal=True)
propensity = (c1.number_input("Probability", 0.01, 0.99, 0.5, 0.05) if prop_mode == "Constant"
              else c1.selectbox("Probability column", cols))
cost = c2.number_input("Cost of treating (outcome units)", value=0.5, step=0.1,
                       help="Treat someone when their predicted benefit exceeds this.")
tol = c3.number_input("Tolerance (per person)", value=0.01, min_value=0.0, step=0.005, format="%.4f",
                      help="The largest average loss per person you accept by not recalibrating.")
with st.expander("Advanced"):
    a1, a2, a3 = st.columns(3)
    alpha = a1.number_input("Error level α", 0.001, 0.2, 0.05, 0.01)
    looks = a2.number_input("Planned looks", 1, 20, 1, help="How many times you will check a growing pilot.")
    lower_better = a3.checkbox("Lower outcome is better")
    challengers = st.multiselect("Challenger policies", ["shrink", "linear", "forest"], default=["shrink", "linear"])
    flex = st.checkbox("Run flexible-model diagnostic (slower)", value=True)

if st.button("Run audit", type="primary", disabled=not features or not challengers):
    with st.spinner("Cross-fitting and bootstrapping…"):
        try:
            r = audit(df, features, treatment, outcome, source, propensity, cost=cost, tolerance=tol, alpha=alpha,
                      looks=int(looks), recalibration=challengers[0], challengers=challengers,
                      flexible_check=flex, higher_is_better=not lower_better)
        except ValueError as e:
            st.error(str(e)); st.stop()
    box = {KEEP: st.success, RECAL: st.info}.get(r.decision, st.warning)
    box(f"**{r.decision}** — {r.headline}")
    for x in r.reasons:
        st.write("• " + x)
    m1, m2, m3 = st.columns(3)
    m1.metric("Gain from recalibrating / person", f"{r.gain_estimate:+.4f}", help=f"bounds {r.gain_lower:+.4f} to {r.gain_upper:+.4f}")
    m2.metric("Pilot decisions that differ", f"{r.n_disagree} ({100*r.disagreement_rate:.1f}%)")
    m3.metric("Suggested total pilot", f"{r.suggested_total_n:,}" if r.suggested_total_n else "–")
    for w in r.warnings:
        st.warning(w)
    st.dataframe(pd.DataFrame(r.challenger_table))
    html_report = to_html(r, dataset_name=name)
    d1, d2, d3 = st.columns(3)
    d1.download_button("HTML report", html_report, "policyaudit_report.html", "text/html")
    d2.download_button("JSON", r.to_json(), "policyaudit_result.json", "application/json")
    buf = io.BytesIO(); pickle.dump(r, buf)
    d3.download_button("Model (for `policyaudit apply`)", buf.getvalue(), "policyaudit_model.pkl")

st.caption("Assumes the pilot was randomized with known probabilities and represents the people the policy will be "
           "used on. Results are approximate, per-person averages. See the policyaudit manual for details.")
