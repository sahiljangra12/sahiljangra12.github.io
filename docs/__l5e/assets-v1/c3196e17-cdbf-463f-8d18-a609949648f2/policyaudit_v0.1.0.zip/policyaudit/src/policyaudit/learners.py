"""Effect learners used to build the recalibrated policy and the outcome nuisance model.

All learners take a numeric, already-standardised feature matrix X (n x p), a binary
treatment vector T and an outcome vector Y, and expose ``predict_cate(X)``.
The source model's predicted effects are passed in as an array where needed, so the
tool never needs the source model itself.
"""
from __future__ import annotations

import numpy as np


def _design(X):
    return np.column_stack([np.ones(len(X)), X])


class LinearOutcomeModel:
    """Y ~ [1, X] + T * [1, X]. Used for AIPW augmentation (needs no correctness)."""

    def fit(self, X, T, Y, ridge: float = 1e-6):
        B = _design(X)
        Z = np.column_stack([B, T[:, None] * B])
        A = Z.T @ Z + ridge * np.eye(Z.shape[1])
        self.coef = np.linalg.solve(A, Z.T @ Y)
        self.k = B.shape[1]
        return self

    def mu(self, X, t):
        B = _design(X)
        return B @ self.coef[: self.k] + t * (B @ self.coef[self.k:])

    def predict_cate(self, X):
        return _design(X) @ self.coef[self.k:]


class LinearRefit(LinearOutcomeModel):
    """Target-only linear interaction model (ignores the source model)."""
    name = "linear"

    def fit(self, X, T, Y, source_cate=None, rng=None):
        return super().fit(X, T, Y)


class ShrinkToSource:
    """Target effect = source prediction + ridge-penalised linear correction.

    Model:  Y = B(x) a + T * (s(x) + E(x) d) + e,   penalty lam * ||d||^2,
    where s(x) is the source model's predicted effect, B(x) = E(x) = [1, x].
    lam is chosen by K-fold CV of outcome prediction error over a grid that includes
    0 (= pure target refit) and a very large value (= keep the source effect).
    """
    name = "shrink"
    GRID = np.r_[0.0, np.logspace(-1, 4, 11), 1e8]

    def fit(self, X, T, Y, source_cate, rng, folds: int = 5):
        B = _design(X)
        Z = np.column_stack([B, T[:, None] * B])
        y = Y - T * source_cate
        self.k = B.shape[1]
        n = len(y)
        idx = rng.permutation(n) % min(folds, n)
        errs = []
        for lam in self.GRID:
            e = 0.0
            for f in np.unique(idx):
                tr, te = idx != f, idx == f
                c = self._solve(Z[tr], y[tr], lam)
                e += float(np.sum((y[te] - Z[te] @ c) ** 2))
            errs.append(e)
        self.lam = float(self.GRID[int(np.argmin(errs))])
        self.coef = self._solve(Z, y, self.lam)
        return self

    def _solve(self, Z, y, lam):
        P = np.zeros(Z.shape[1])
        P[self.k:] = lam
        A = Z.T @ Z + np.diag(P) + 1e-8 * np.eye(Z.shape[1])
        return np.linalg.solve(A, Z.T @ y)

    def predict_cate(self, X, source_cate):
        return source_cate + _design(X) @ self.coef[self.k:]


class ForestTLearner:
    """Random-forest T-learner; used as the flexible recalibration option and for the
    'is a flexible model clearly better?' diagnostic."""
    name = "forest"

    def __init__(self, n_estimators: int = 300, min_samples_leaf: int = 10, seed: int = 0):
        self.kw = dict(n_estimators=n_estimators, min_samples_leaf=min_samples_leaf, random_state=seed, n_jobs=1)

    def fit(self, X, T, Y, source_cate=None, rng=None):
        from sklearn.ensemble import RandomForestRegressor
        self.m1 = RandomForestRegressor(**self.kw).fit(X[T == 1], Y[T == 1])
        self.m0 = RandomForestRegressor(**self.kw).fit(X[T == 0], Y[T == 0])
        return self

    def predict_cate(self, X, source_cate=None):
        return self.m1.predict(X) - self.m0.predict(X)


def make_learner(kind: str, seed: int = 0):
    if kind == "shrink":
        return ShrinkToSource()
    if kind == "linear":
        return LinearRefit()
    if kind == "forest":
        return ForestTLearner(seed=seed)
    raise ValueError(f"unknown recalibration learner {kind!r}; use 'shrink', 'linear' or 'forest'")


def predict(learner, X, source_cate):
    if isinstance(learner, (ShrinkToSource, ForestTLearner)):
        return learner.predict_cate(X, source_cate)
    return learner.predict_cate(X)
