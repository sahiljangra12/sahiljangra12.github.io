"""Self-contained HTML report for an AuditResult."""
from __future__ import annotations

import html
import datetime as _dt

from .audit import KEEP, RECAL, MORE

_COL = {KEEP: ("#065f46", "#d1fae5"), RECAL: ("#1e3a8a", "#dbeafe"), MORE: ("#92400e", "#fef3c7")}


def _f(x, d=4, sign=False):
    if x is None:
        return "–"
    try:
        return f"{x:+.{d}f}" if sign else f"{x:.{d}f}"
    except (TypeError, ValueError):
        return html.escape(str(x))


def _interval_svg(lo, est, hi, tol):
    """Number line showing the gain interval against 0 and the tolerance."""
    pts = [lo, hi, 0.0, tol, est]
    a, b = min(pts), max(pts)
    pad = 0.12 * (b - a or 1.0)
    a, b = a - pad, b + pad
    W, H, L, R = 640, 96, 20, 20
    X = lambda v: L + (v - a) / (b - a) * (W - L - R)
    zone = f'<rect x="{X(0):.1f}" y="22" width="{max(X(tol) - X(0), 1):.1f}" height="40" fill="var(--zone)"/>'
    return f'''<svg viewBox="0 0 {W} {H}" role="img" aria-label="Estimated gain interval" style="width:100%;max-width:{W}px">
  {zone}
  <line x1="{L}" y1="42" x2="{W - R}" y2="42" stroke="var(--axis)" stroke-width="1"/>
  <line x1="{X(0):.1f}" y1="16" x2="{X(0):.1f}" y2="68" stroke="var(--ink)" stroke-width="1.2"/>
  <text x="{X(0):.1f}" y="84" text-anchor="middle" font-size="11" fill="var(--muted)">0 (no gain)</text>
  <line x1="{X(tol):.1f}" y1="16" x2="{X(tol):.1f}" y2="68" stroke="var(--warn)" stroke-width="1.2" stroke-dasharray="4 3"/>
  <text x="{X(tol):.1f}" y="12" text-anchor="middle" font-size="11" fill="var(--warn)">tolerance {tol:g}</text>
  <line x1="{X(lo):.1f}" y1="42" x2="{X(hi):.1f}" y2="42" stroke="var(--accent)" stroke-width="6" stroke-linecap="round"/>
  <circle cx="{X(est):.1f}" cy="42" r="6" fill="var(--bg)" stroke="var(--accent)" stroke-width="3"/>
</svg>'''


def to_html(r, title="Policy audit report", dataset_name=None) -> str:
    fg, bg = _COL[r.decision]
    e = html.escape
    reasons = "".join(f"<li>{e(x)}</li>" for x in r.reasons)
    warns = "".join(f"<li>{e(x)}</li>" for x in r.warnings) or "<li class='muted'>None.</li>"
    rows = "".join(
        f"<tr><td>{e(t['challenger'])}</td><td>{_f(t['gain'], sign=True)}</td><td>{_f(t['lower'], sign=True)}</td>"
        f"<td>{_f(t['upper'], sign=True)}</td><td>{t['n_disagree']}</td><td>{'yes' if t['reliable'] else 'no – can only support KEEP'}</td></tr>"
        for t in r.challenger_table)
    cs = r.calibration_slope_ci
    settings = "".join(f"<tr><td>{e(str(k))}</td><td>{e(str(v))}</td></tr>" for k, v in r.settings.items())
    meaning = {
        KEEP: "Recalibrating would gain less than your tolerance per person, with the stated confidence. Keep the existing policy; no new model is needed.",
        RECAL: "A policy recalibrated on the pilot is better with the stated confidence. Use the recalibrated model (saved with --save-model) to make treatment decisions.",
        MORE: "The evidence is not yet strong enough either way. Continue the randomized pilot and re-run the audit; set --looks to the number of times you plan to check.",
    }[r.decision]
    now = _dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    ds = f" · data: {e(dataset_name)}" if dataset_name else ""
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{e(title)}</title>
<style>
:root{{--bg:#ffffff;--ink:#111827;--muted:#6b7280;--line:#e5e7eb;--card:#f9fafb;--accent:#2563eb;--warn:#b45309;--zone:#fde68a55;--axis:#9ca3af}}
@media (prefers-color-scheme:dark){{:root{{--bg:#0f1115;--ink:#e5e7eb;--muted:#9ca3af;--line:#262a33;--card:#161a21;--accent:#60a5fa;--warn:#f59e0b;--zone:#f59e0b22;--axis:#4b5563}}}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}}
main{{max-width:860px;margin:0 auto;padding:32px 16px 64px}}h1{{font-size:22px;margin:0 0 4px}}h2{{font-size:16px;margin:32px 0 8px}}
.meta{{color:var(--muted);font-size:13px}}.card{{border:1px solid var(--line);background:var(--card);border-radius:10px;padding:16px 18px;margin:12px 0}}
.decision{{background:{bg};color:{fg};border:none}}.decision .big{{font-size:26px;font-weight:700;letter-spacing:.02em}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px}}.stat .v{{font-size:20px;font-weight:600;font-variant-numeric:tabular-nums}}
.stat .k{{color:var(--muted);font-size:12px}}table{{border-collapse:collapse;width:100%;font-size:13.5px;font-variant-numeric:tabular-nums}}
td,th{{text-align:left;padding:6px 8px;border-bottom:1px solid var(--line)}}th{{color:var(--muted);font-weight:600}}.muted{{color:var(--muted)}}
ul{{padding-left:20px;margin:6px 0}}.scroll{{overflow-x:auto}}code{{font-size:13px}}
@media (prefers-color-scheme:dark){{.decision{{filter:brightness(.92)}}}}
</style></head><body><main>
<h1>{e(title)}</h1><div class="meta">policyaudit · generated {now}{ds} · pilot of {r.n:,} randomized units</div>
<div class="card decision"><div class="big">{e(r.decision)}</div><div>{e(r.headline)}</div></div>
<p>{e(meaning)}</p>
<h2>Why</h2><ul>{reasons}</ul>
<h2>Estimated gain from recalibrating</h2>
<div class="card">{_interval_svg(r.gain_lower, r.gain_estimate, r.gain_upper, r.tolerance)}
<div class="meta">Point: estimate for the '{e(r.recalibration)}' challenger. Bar: one-sided bounds at level {r.alpha_per_look:.3g} combined
({e(r.interval_method)}). Shaded: gains between 0 and your tolerance (switching not worth it). KEEP needs the whole bar left of the dashed line;
RECALIBRATE needs it right of 0.</div></div>
<div class="grid">
<div class="card stat"><div class="k">Gain per person</div><div class="v">{_f(r.gain_estimate, sign=True)}</div></div>
<div class="card stat"><div class="k">Pilot decisions that differ</div><div class="v">{r.n_disagree} ({100 * r.disagreement_rate:.1f}%)</div></div>
<div class="card stat"><div class="k">Treated: source → recalibrated</div><div class="v">{100 * r.treat_rate_source:.0f}% → {100 * r.treat_rate_recal:.0f}%</div></div>
<div class="card stat"><div class="k">Suggested total pilot size</div><div class="v">{f"{r.suggested_total_n:,}" if r.suggested_total_n else "–"}</div></div>
</div>
<h2>Warnings and checks</h2><ul>{warns}</ul>
<h2>All challengers tested</h2><div class="scroll"><table><tr><th>Challenger</th><th>Gain</th><th>Lower</th><th>Upper</th><th>Decisions changed</th><th>Enough to judge?</th></tr>{rows}</table></div>
<h2>Context</h2><div class="scroll"><table>
<tr><td>Estimated net benefit per person: source policy / recalibrated / treat everyone / treat no one</td><td>{_f(r.value_source)} / {_f(r.value_recal)} / {_f(r.value_treat_all)} / 0</td></tr>
<tr><td>Average treatment effect in the pilot (95% CI)</td><td>{_f(r.ate_target)} ({_f(r.ate_target_ci[0])} to {_f(r.ate_target_ci[1])})</td></tr>
<tr><td>Average effect the source model predicts for the same people</td><td>{_f(r.ate_source_pred)}</td></tr>
<tr><td>Calibration slope of source predictions in the pilot (1 = differences between people hold up)</td><td>{_f(r.calibration_slope, 2)} ({_f(cs[0], 2)} to {_f(cs[1], 2)})</td></tr>
<tr><td>Gain of a flexible (forest) policy over the chosen one</td><td>{_f(r.flexible_gain, sign=True)}</td></tr>
<tr><td>Shrinkage strength chosen by cross-validation</td><td>{_f(r.shrink_lambda, 3)}</td></tr>
</table></div>
<h2>What this audit assumes</h2><ul>
<li>Pilot units were assigned treatment at random with the stated, known probability, and are representative of the people the policy will be used on.</li>
<li>Outcomes and the cost are in the same units, and the source predictions are on that scale in the direction of benefit.</li>
<li>The gain is an average per person; it says nothing about any individual's outcome.</li>
<li>Confidence statements are approximate (large-sample) and hold for one look; with repeated looks set <code>looks</code> accordingly.</li></ul>
<h2>Settings</h2><div class="scroll"><table>{settings}</table></div>
</main></body></html>'''
