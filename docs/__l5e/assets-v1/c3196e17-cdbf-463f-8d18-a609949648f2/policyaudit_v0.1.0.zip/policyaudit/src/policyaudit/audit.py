"""The policy audit: keep, recalibrate, or collect more target data?

Setting
-------
A treatment-targeting policy was built elsewhere (the *source*): a model predicts each
person's treatment effect s(x) and the policy treats when s(x) > cost. Before relying on
it in a new setting (the *target*), you run a small randomized pilot: each unit gets
treatment with a known probability e(x), and you record the outcome.

What the audit estimates
------------------------
    D = V(pi_recal) - V(pi_source),   V(pi) = E_target[ pi(X) * (tau(X) - cost) ]

the per-person gain in net benefit from switching to a policy recalibrated on the pilot.
It is estimated with AIPW pseudo-outcomes (valid because e(x) is known) and K-fold
cross-fitting (each unit is scored by models that never saw it). Only units on which the
two policies disagree contribute, so a change in the model that does not change any
decision does not trigger a switch.

Decision (tolerance eps, level alpha split over the number of planned looks):
    KEEP          upper bound on D  < eps   (recalibrating gains at most eps per person)
    RECALIBRATE   lower bound on D  > 0     (recalibrating is better, with confidence)
    COLLECT MORE  otherwise
Several recalibrated policies ("challengers", by default a shrink-to-source correction and
a target-only linear refit) are tested at once, with the error level split among them.
A challenger that changes fewer than ``min_disagreements`` pilot decisions may support
KEEP but never triggers RECALIBRATE. Bounds are the more conservative of a normal and a
bootstrap interval. These rules follow the findings of Experiment 002.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Callable, Optional, Sequence, Union
import json
import warnings

import numpy as np
import pandas as pd
from scipy import stats

from .learners import LinearOutcomeModel, ForestTLearner, make_learner, predict

KEEP, RECAL, MORE = "KEEP", "RECALIBRATE", "COLLECT MORE"


# --------------------------------------------------------------------- inputs
@dataclass
class FeatureMap:
    columns: list
    dummies: list
    mean: np.ndarray
    sd: np.ndarray

    def transform(self, df: pd.DataFrame) -> np.ndarray:
        X = pd.get_dummies(df[self.columns], drop_first=True, dtype=float)
        X = X.reindex(columns=self.dummies, fill_value=0.0)
        return (X.to_numpy(float) - self.mean) / self.sd


def build_features(df: pd.DataFrame, columns: Sequence[str]) -> FeatureMap:
    X = pd.get_dummies(df[list(columns)], drop_first=True, dtype=float)
    A = X.to_numpy(float)
    sd = A.std(0)
    sd[sd == 0] = 1.0
    return FeatureMap(list(columns), list(X.columns), A.mean(0), sd)


# --------------------------------------------------------------------- result
@dataclass
class AuditResult:
    decision: str
    headline: str
    reasons: list
    warnings: list
    n: int
    cost: float
    tolerance: float
    alpha_per_look: float
    recalibration: str
    # value contrast (for the decisive challenger)
    gain_estimate: float
    gain_lower: float
    gain_upper: float
    gain_se: float
    disagreement_rate: float
    n_disagree: int
    interval_method: str
    challenger_table: list
    # context
    value_source: float
    value_recal: float
    value_treat_all: float
    treat_rate_source: float
    treat_rate_recal: float
    ate_target: float
    ate_target_ci: tuple
    ate_source_pred: float
    calibration_slope: float
    calibration_slope_ci: tuple
    flexible_gain: Optional[float] = None
    flexible_gain_lower: Optional[float] = None
    suggested_total_n: Optional[int] = None
    shrink_lambda: Optional[float] = None
    settings: dict = field(default_factory=dict)
    recalibrated_model: object = field(default=None, repr=False)
    feature_map: object = field(default=None, repr=False)

    def to_dict(self):
        d = asdict(self)
        d.pop("recalibrated_model", None); d.pop("feature_map", None)
        return d

    def to_json(self, path=None):
        s = json.dumps(self.to_dict(), indent=2, default=float)
        if path:
            open(path, "w").write(s)
        return s

    def summary(self) -> str:
        lines = [f"DECISION: {self.decision}", self.headline, ""]
        lines += [f"  Estimated gain from recalibrating: {self.gain_estimate:+.4f} per person "
                  f"[{self.gain_lower:+.4f}, {self.gain_upper:+.4f}] ({self.interval_method})",
                  f"  Tolerance: {self.tolerance:g}   Pilot size: {self.n}   Units decided differently: "
                  f"{self.n_disagree} ({100*self.disagreement_rate:.1f}%)", ""]
        lines += ["Why:"] + [f"  - {r}" for r in self.reasons]
        if self.warnings:
            lines += ["", "Warnings:"] + [f"  ! {w}" for w in self.warnings]
        return "\n".join(lines)

    def predict(self, df: pd.DataFrame, source_cate) -> np.ndarray:
        """Recalibrated effect predictions for new units (needs their source predictions)."""
        X = self.feature_map.transform(df)
        s = _resolve_array(df, source_cate)
        return predict(self.recalibrated_model, X, s)

    def recommend(self, df: pd.DataFrame, source_cate) -> np.ndarray:
        """Treatment recommendations for new units under the audit's decision."""
        s = _resolve_array(df, source_cate)
        if self.decision == RECAL:
            return (self.predict(df, s) > self.cost).astype(int)
        return (s > self.cost).astype(int)


def _resolve_array(df, spec, name="value"):
    if isinstance(spec, str):
        return df[spec].to_numpy(float)
    if callable(spec):
        return np.asarray(spec(df), float)
    if np.isscalar(spec):
        return np.full(len(df), float(spec))
    a = np.asarray(spec, float)
    if a.shape != (len(df),):
        raise ValueError(f"{name} must have one value per row")
    return a


# ------------------------------------------------------------------- helpers
def _mean_bounds(x, alpha, rng, n_boot):
    """One-sided (1-alpha) lower and upper bounds for E[x]: the more conservative of
    the normal approximation and a percentile bootstrap."""
    n = len(x)
    m = x.mean()
    se = x.std(ddof=1) / np.sqrt(n)
    z = stats.norm.ppf(1 - alpha)
    lo_n, hi_n = m - z * se, m + z * se
    if n_boot and se > 0:
        idx = rng.integers(0, n, size=(n_boot, n))
        bm = x[idx].mean(1)
        lo_b, hi_b = np.quantile(bm, alpha), np.quantile(bm, 1 - alpha)
        return m, se, min(lo_n, lo_b), max(hi_n, hi_b)
    return m, se, lo_n, hi_n


def _blp_slope(gamma, pred):
    """Best-linear-predictor calibration slope of pseudo-outcomes on predictions (HC1)."""
    p = pred - pred.mean()
    if np.allclose(p, 0):
        return np.nan, (np.nan, np.nan)
    Z = np.column_stack([np.ones_like(p), p])
    coef, *_ = np.linalg.lstsq(Z, gamma, rcond=None)
    r = gamma - Z @ coef
    n = len(r)
    ZtZi = np.linalg.inv(Z.T @ Z)
    V = ZtZi @ ((Z * r[:, None] ** 2).T @ Z) @ ZtZi * n / (n - 2)
    se = np.sqrt(V[1, 1])
    return float(coef[1]), (float(coef[1] - 1.96 * se), float(coef[1] + 1.96 * se))


# ---------------------------------------------------------------------- main
def audit(
    data: pd.DataFrame,
    features: Sequence[str],
    treatment: str,
    outcome: str,
    source_cate: Union[str, np.ndarray, Callable],
    propensity: Union[float, str, np.ndarray] = 0.5,
    cost: float = 0.0,
    tolerance: float = 0.01,
    alpha: float = 0.05,
    looks: int = 1,
    recalibration: str = "shrink",
    challengers: Optional[Sequence[str]] = ("shrink", "linear"),
    folds: int = 5,
    n_boot: int = 2000,
    min_disagreements: int = 20,
    min_recal_n: int = 400,
    flexible_check: bool = True,
    higher_is_better: bool = True,
    seed: int = 0,
) -> AuditResult:
    """Audit a source treatment policy on a randomized target pilot.

    Parameters
    ----------
    data : one row per pilot unit.
    features : covariate columns (numeric or categorical; categoricals are one-hot encoded).
    treatment : 0/1 column, assigned at random with known probability ``propensity``.
    outcome : outcome column. If lower is better (e.g. cost, days in hospital) set
        ``higher_is_better=False``; the tool then works with the negated outcome.
    source_cate : the source model's predicted treatment effect for each pilot unit
        (column name, array, or function of the data frame), on the same scale as the
        outcome *in the direction of benefit*.
    propensity : known treatment probability (constant, column name, or array).
    cost : treat when predicted benefit exceeds this (outcome units per person).
    tolerance : largest per-person loss in net benefit you are willing to accept by
        keeping the source policy instead of recalibrating.
    alpha : error level for each one-sided bound; divided by ``looks`` (Bonferroni)
        if you plan to look at the pilot several times as it grows.
    recalibration : preferred recalibration learner: 'shrink' (source prediction +
        penalised linear correction), 'linear' (target-only linear refit) or 'forest'
        (random-forest T-learner). Always included among the challengers.
    challengers : recalibrated policies the source is tested against. The error level
        is split equally among them; the switch goes to the one with the highest
        confident gain. A challenger that changes fewer than ``min_disagreements``
        pilot decisions can support KEEP but never triggers RECALIBRATE.
    """
    rng = np.random.default_rng(seed)
    df = data.copy()
    needed = list(features) + [treatment, outcome] + [c for c in (source_cate, propensity) if isinstance(c, str)]
    missing = [c for c in needed if c not in df.columns]
    if missing:
        raise ValueError(f"columns not found: {missing}")
    before = len(df)
    df = df.dropna(subset=needed).reset_index(drop=True)
    warn = []
    if len(df) < before:
        warn.append(f"Dropped {before - len(df)} rows with missing values in the columns used.")
    n = len(df)
    if n < 50:
        raise ValueError("need at least 50 pilot units")

    T = df[treatment].to_numpy()
    if not set(np.unique(T)) <= {0, 1}:
        raise ValueError("treatment must be coded 0/1")
    T = T.astype(int)
    if T.sum() < 10 or (1 - T).sum() < 10:
        raise ValueError("need at least 10 treated and 10 untreated pilot units")
    Y = df[outcome].to_numpy(float) * (1.0 if higher_is_better else -1.0)
    s = _resolve_array(df, source_cate, "source_cate")
    e = _resolve_array(df, propensity, "propensity")
    if np.any((e <= 0) | (e >= 1)):
        raise ValueError("propensity must be strictly between 0 and 1")
    if np.any((e < 0.05) | (e > 0.95)):
        warn.append("Some treatment probabilities are below 0.05 or above 0.95; estimates will be noisy.")

    fmap = build_features(df, features)
    X = fmap.transform(df)
    a = alpha / max(int(looks), 1)

    # ---------------------------------------------------------- cross-fitting
    challengers = list(dict.fromkeys(challengers or [recalibration]))
    if recalibration not in challengers:
        challengers.insert(0, recalibration)
    a_ch = a / len(challengers)                      # Bonferroni across challengers
    K = int(min(folds, n // 10))
    fold = rng.permutation(n) % K
    mu0 = np.empty(n); mu1 = np.empty(n); f_cate = np.empty(n)
    ch_cate = {c: np.empty(n) for c in challengers}
    for k in range(K):
        tr, te = fold != k, fold == k
        om = LinearOutcomeModel().fit(X[tr], T[tr], Y[tr])
        mu0[te], mu1[te] = om.mu(X[te], 0), om.mu(X[te], 1)
        for c in challengers:
            lr = make_learner(c, seed=seed + k).fit(X[tr], T[tr], Y[tr], source_cate=s[tr], rng=rng)
            ch_cate[c][te] = predict(lr, X[te], s[te])
        if flexible_check and "forest" not in challengers:
            fl = ForestTLearner(seed=seed + 100 + k).fit(X[tr], T[tr], Y[tr])
            f_cate[te] = fl.predict_cate(X[te])
    gamma = mu1 - mu0 + T * (Y - mu1) / e - (1 - T) * (Y - mu0) / (1 - e)
    net = gamma - cost
    pi_s = (s > cost).astype(float)

    table = []
    for c in challengers:
        pi_c = (ch_cate[c] > cost).astype(float)
        contrib = (pi_c - pi_s) * net
        m, se_c, lo, hi = _mean_bounds(contrib, a_ch, rng, n_boot)
        nd = int(np.sum(pi_c != pi_s))
        table.append(dict(challenger=c, gain=float(m), se=float(se_c), lower=float(lo), upper=float(hi),
                          n_disagree=nd, reliable=nd >= min_disagreements, sd=float(contrib.std(ddof=1)),
                          pi=pi_c))

    reasons = []
    winners = [t for t in table if t["reliable"] and t["lower"] > 0]
    if winners:
        best = max(winners, key=lambda t: t["lower"])
        decision = RECAL
        recalibration = best["challenger"]
        reasons.append(f"With {100*(1-a):.1f}% confidence (split over {len(challengers)} challenger policies), the "
                       f"'{best['challenger']}' recalibration is better: at least {best['lower']:.4f} more net benefit "
                       f"per person (estimate {best['gain']:.4f}).")
    elif all(t["upper"] < tolerance for t in table):
        decision = KEEP
        best = max(table, key=lambda t: t["upper"])
        reasons.append(f"With {100*(1-a):.1f}% confidence, none of the recalibrated policies ({', '.join(challengers)}) "
                       f"would improve net benefit by more than {best['upper']:.4f} per person, below your tolerance "
                       f"of {tolerance:g}.")
        rare = [t["challenger"] for t in table if not t["reliable"]]
        if rare:
            reasons.append(f"The {', '.join(rare)} recalibration changes fewer than {min_disagreements} pilot decisions, "
                           f"so for those people the choice of policy makes no practical difference.")
    else:
        decision = MORE
        best = max(table, key=lambda t: t["upper"])
        reasons.append(f"The pilot cannot yet tell: for the '{best['challenger']}' recalibration the gain is between "
                       f"{best['lower']:+.4f} and {best['upper']:+.4f} per person, which includes both zero and values "
                       f"above the tolerance {tolerance:g}.")
        if not best["reliable"] and best["lower"] > 0:
            reasons.append(f"It looks better, but it changes only {best['n_disagree']} pilot decisions, too few to trust.")
    d_hat, se, lcb, ucb, n_dis, pi_r = best["gain"], best["se"], best["lower"], best["upper"], best["n_disagree"], best["pi"]
    method = f"cross-fitted AIPW; conservative of normal and bootstrap; alpha {a_ch:.4f} per bound"

    # -------------------------------------------------- sample-size guidance
    suggested = None
    if decision == MORE:
        sd = max(best["sd"], 1e-12)
        z = stats.norm.ppf(1 - a_ch)
        cands = []
        if d_hat < tolerance:
            cands.append((z * sd / (tolerance - d_hat)) ** 2)
        if d_hat > 0:
            cands.append((z * sd / d_hat) ** 2)
        if not best["reliable"]:
            cands = [max(c, min_disagreements * n / max(n_dis, 1)) for c in cands] or [min_disagreements * n / max(n_dis, 1)]
        need = int(np.ceil(min(cands))) if cands else None
        suggested = need if need and need <= 50 * n else None
        if suggested:
            reasons.append(f"If the current estimate holds, about {suggested:,} pilot units in total would be needed to "
                           f"decide (a rough planning figure; the estimate will move as data arrive).")
        else:
            reasons.append("The estimate sits so close to a decision boundary that no practical pilot size is likely to "
                           "settle it; the choice may matter little either way.")

    # ---------------------------------------------------- deployable model
    final = make_learner(recalibration, seed=seed).fit(X, T, Y, source_cate=s, rng=rng)
    full_cate = predict(final, X, s)
    lam = getattr(final, "lam", None)
    if decision == RECAL and n < min_recal_n:
        warn.append(f"The recalibrated model is fitted on only {n} units. In simulation, policies fitted this early "
                    f"were noticeably worse than ones fitted on {min_recal_n}+; consider continuing the pilot before deploying.")

    # ------------------------------------------------------- absolute checks
    chosen = pi_r if decision == RECAL else pi_s
    v_s, v_r, v_all = float(np.mean(pi_s * net)), float(np.mean(pi_r * net)), float(np.mean(net))
    _, _, _, up_vs_all = _mean_bounds((chosen - 1) * net, a, rng, n_boot)
    _, _, _, up_vs_none = _mean_bounds(chosen * net, a, rng, n_boot)
    if up_vs_all < 0:
        warn.append("Treating everyone looks clearly better than the chosen policy on this pilot. Neither the source "
                    "nor the recalibrated model is targeting well; revisit the model.")
    if up_vs_none < 0:
        warn.append("Treating no one looks clearly better than the chosen policy on this pilot. Neither candidate "
                    "policy is beneficial at this cost; revisit the model or the cost.")
    slope, slope_ci = _blp_slope(gamma, s)
    if not np.isnan(slope) and slope_ci[1] < 0.5:
        warn.append(f"The source model's predicted differences between people are not borne out in the pilot "
                    f"(calibration slope {slope:.2f}, 95% CI {slope_ci[0]:.2f} to {slope_ci[1]:.2f}; 1 = perfect).")
    fg = fgl = None
    if flexible_check and "forest" not in challengers:
        pi_f = (f_cate > cost).astype(float)
        fg, _, fgl, _ = _mean_bounds((pi_f - chosen) * net, a, rng, n_boot)
        if fgl > 0 and fg > tolerance:
            warn.append(f"A flexible (random-forest) model would do better than the chosen policy by about {fg:.4f} per "
                        f"person. The treatment effect may be nonlinear in ways the linear correction cannot capture; "
                        f"consider recalibration='forest' or a richer model.")
    ate, ate_se = float(gamma.mean()), float(gamma.std(ddof=1) / np.sqrt(n))
    if abs(ate - s.mean()) > 1.96 * ate_se and decision == KEEP:
        reasons.append("The average effect in the pilot differs from what the source model predicts, but that shift "
                       "does not change who should be treated enough to matter at your tolerance.")

    headline = {
        KEEP: "Keep using the source policy in this setting.",
        RECAL: "Switch to the recalibrated policy for this setting.",
        MORE: "Not enough evidence yet: keep collecting randomized pilot data before deciding.",
    }[decision]
    settings = dict(features=list(features), treatment=treatment, outcome=outcome,
                    source_cate=source_cate if isinstance(source_cate, str) else "<array>",
                    propensity=propensity if isinstance(propensity, (str, float, int)) else "<array>",
                    cost=cost, tolerance=tolerance, alpha=alpha, looks=looks, recalibration=recalibration,
                    challengers=challengers, folds=K, n_boot=n_boot, min_disagreements=min_disagreements, min_recal_n=min_recal_n,
                    flexible_check=flexible_check, higher_is_better=higher_is_better, seed=seed)
    return AuditResult(
        decision=decision, headline=headline, reasons=reasons, warnings=warn, n=n, cost=cost, tolerance=tolerance,
        alpha_per_look=a, recalibration=recalibration, gain_estimate=float(d_hat), gain_lower=float(lcb),
        gain_upper=float(ucb), gain_se=float(se), disagreement_rate=n_dis / n, n_disagree=n_dis,
        interval_method=method,
        challenger_table=[{k: v for k, v in t.items() if k not in ("pi", "sd")} for t in table], value_source=v_s, value_recal=v_r, value_treat_all=v_all,
        treat_rate_source=float(pi_s.mean()), treat_rate_recal=float((full_cate > cost).mean()),
        ate_target=ate, ate_target_ci=(ate - 1.96 * ate_se, ate + 1.96 * ate_se), ate_source_pred=float(s.mean()),
        calibration_slope=slope, calibration_slope_ci=slope_ci, flexible_gain=fg, flexible_gain_lower=fgl,
        suggested_total_n=suggested, shrink_lambda=lam, settings=settings, recalibrated_model=final, feature_map=fmap)
