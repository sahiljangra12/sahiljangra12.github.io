# policyaudit

**Keep, recalibrate, or collect more?** A decision audit for treatment-targeting policies moved to a new setting.

You have a model that predicts who benefits from a treatment (an outreach call, a training offer, a reminder, a discount), built in one place or time. You want to use it somewhere new. You run a small **randomized pilot** there. `policyaudit` turns that pilot into one of three decisions, with the evidence behind it:

| Decision | Meaning |
|---|---|
| **KEEP** | Recalibrating would gain less than your tolerance per person, with stated confidence. |
| **RECALIBRATE** | A policy recalibrated on the pilot is better, with stated confidence. A deployable model is provided. |
| **COLLECT MORE** | The pilot can't tell yet. A rough target pilot size is suggested. |

It is model-agnostic: you supply your model's *predicted effect* for each pilot participant, not the model.

## Install
```bash
pip install .            # core
pip install ".[app]"     # + point-and-click app
```

## Use
```bash
policyaudit demo --scenario intercept_drop --n 1600 --out pilot.csv     # synthetic data to try
policyaudit run pilot.csv --features age_z risk_z --treatment treated --outcome outcome \
    --source-cate source_effect --propensity 0.5 --cost 0.5 --tolerance 0.01 \
    --report report.html --save-model audit.pkl
policyaudit apply audit.pkl new_people.csv --source-cate source_effect --out decisions.csv
policyaudit app                                                         # browser app
```
```python
import policyaudit as pa
r = pa.audit(pilot, features=["age_z", "risk_z"], treatment="treated", outcome="outcome",
             source_cate="source_effect", propensity=0.5, cost=0.5, tolerance=0.01)
print(r.summary())
```

## How it decides (short version)
It estimates the per-person gain in net benefit from switching to a recalibrated policy, using AIPW pseudo-outcomes (valid because pilot randomization probabilities are known) and 5-fold cross-fitting. Only people on whom the policies disagree count, so model changes that don't change decisions don't trigger a switch. Two challengers are tested by default (a shrink-to-source correction and a target-only refit) with the error level split between them. Bounds are the more conservative of normal and bootstrap intervals. Diagnostics warn when treating everyone/no one beats the chosen policy, when the source model's predicted differences don't hold up, when a flexible model clearly does better, and when recalibrating on a very small pilot.

Full method, assumptions, validation and reference: **`docs/policyaudit_manual.pdf`**.

## Requirements and limits
- The pilot **must be randomized** with known treatment probabilities. Not for observational data.
- The pilot must represent the people the policy will be used on.
- Bounds are large-sample approximations; results are population averages, not individual guarantees.
- Validated in simulation (`validation/`): across 3,000 simulated audits, wrong RECALIBRATE decisions were at most 1% per scenario; wrong KEEP decisions were at most 8% except in a nonlinear scenario where all linear candidates are inadequate (up to 14% at large pilots). At a strict tolerance the tool often asks for more data. See the manual's Validation section.
- `--save-model` writes a Python pickle: only load pickles you created.

## Test and reproduce
```bash
pip install ".[dev]" && python -m pytest tests
python validation/run_validation.py 100 && python validation/run_power.py
python docs/make_tables.py && (cd docs && latexmk -pdf policyaudit_manual.tex)
```

Built on Experiments 001–002 of the Causal AI Research Project. MIT licensed.
